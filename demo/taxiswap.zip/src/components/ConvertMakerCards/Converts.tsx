import React from 'react'
import { Switch} from 'react-router-dom'
import FarmsContainer from './components/FarmsContainer'


const Converts: React.FC = () => {
  return (
    <Switch>
      <FarmsContainer />
    </Switch>
  )
}

export default Converts
