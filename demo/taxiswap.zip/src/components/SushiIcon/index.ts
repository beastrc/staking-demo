export { default } from './SushiIcon'
