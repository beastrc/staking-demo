import { FlattenSimpleInterpolation, ThemedCssFunction } from 'styled-components'

export type Color = string
export interface Colors {
  // base
  white: Color
  black: Color

  // text
  text1: Color
  text2: Color
  text3: Color
  text4: Color
  text5: Color

  // backgrounds / greys
  bg1: Color
  bg2: Color
  bg3: Color
  bg4: Color
  bg5: Color

  modalBG: Color
  advancedBG: Color

  //blues
  primary1: Color
  primary2: Color
  primary3: Color
  primary4: Color
  primary5: Color

  primaryText1: Color

  // pinks
  secondary1: Color
  secondary2: Color
  secondary3: Color

  // other
  red1: Color
  red2: Color
  green1: Color
  yellow1: Color
  yellow2: Color
}

export interface Grids {
  sm: number
  md: number
  lg: number
}

export interface Breakpoints {
  mobile: number
}
interface Breakpoints {
  mobile: string;
}

export interface Spacing {
  1: number
  2: number
  3: number
  4: number
  5: number
  6: number
  7: number
}

export interface grey {
  100: Color
  200: Color
  300: Color
  400: Color
  500: Color
}

export interface primary {
  light: Color
  main: Color
}

export interface secondary {
  main: Color
}

export interface color {
  black: Color
  grey: grey
  primary: primary
  secondary: secondary
  white: Color
}


declare module 'styled-components' {
  export interface DefaultTheme extends Colors {
    grids: Grids

    // shadows
    shadow1: string

    // media queries
    mediaWidth: {
      upToExtraSmall: ThemedCssFunction<DefaultTheme>
      upToSmall: ThemedCssFunction<DefaultTheme>
      upToMedium: ThemedCssFunction<DefaultTheme>
      upToLarge: ThemedCssFunction<DefaultTheme>
    }

    // css snippets
    flexColumnNoWrap: FlattenSimpleInterpolation
    flexRowNoWrap: FlattenSimpleInterpolation

    borderRadius: number
    points : Breakpoints
    
    color : color

    siteWidth : number
    spacing : Spacing
    topBarSize : number
  }
}
