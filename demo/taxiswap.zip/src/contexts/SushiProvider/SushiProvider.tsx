import React, { createContext, useEffect, useState } from 'react'

import { useWallet } from 'use-wallet'
import config from '../../config'

import { Sushi } from '../../sushi'
import { useWeb3React } from '@web3-react/core'
export interface SushiContext {
  sushi?: typeof Sushi
}

export const Context = createContext<SushiContext>({
  sushi: undefined,
})

declare global {
  interface Window {
    sushisauce: any
  }
}

const SushiProvider: React.FC = ({ children }) => {
  const { library: ethereum } = useWeb3React()
  const [sushi, setSushi] = useState<any>()
  
  // @ts-ignore
  window.sushi = sushi
  // @ts-ignore
  window.eth = ethereum

  useEffect(() => {
    if (ethereum && ethereum.provider) {
      const chainId = Number(ethereum.provider.chainId)
      const sushiLib = new Sushi(ethereum.provider, chainId, false, {
        defaultAccount: ethereum.provider.selectedAddress,
        defaultConfirmations: 1,
        autoGasMultiplier: 1.5,
        testing: false,
        defaultGas: '6000000',
        defaultGasPrice: '1000000000000',
        accounts: [],
        ethereumNodeTimeout: 10000,
      })
      setSushi(sushiLib)
      window.sushisauce = sushiLib
    }
    else {
      const chainId = config.chainId
      const sushiLib = new Sushi(config.rpc, chainId, false, {
        defaultAccount: '0x0000000000000000000000000000000000000000',
        defaultConfirmations: 1,
        autoGasMultiplier: 1.5,
        testing: false,
        defaultGas: '6000000',
        defaultGasPrice: '1000000000000',
        accounts: [],
        ethereumNodeTimeout: 10000,
      })
      setSushi(sushiLib)
      window.sushisauce = sushiLib
    }
  }, [ethereum])

  return <Context.Provider value={{ sushi }}>{children}</Context.Provider>
}

export default SushiProvider
