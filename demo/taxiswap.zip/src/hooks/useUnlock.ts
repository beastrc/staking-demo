import { useCallback } from 'react'

import useSushi from './useSushi'
import { useWallet } from 'use-wallet'

import { unlock } from '../sushi/utils'

import { useWeb3React } from '@web3-react/core'

const useUnlock = () => {
  const { account } = useWeb3React()
  const sushi = useSushi()

  const doTx = useCallback(async () => {
    try {
      const txHash = await unlock(sushi, account)
      return txHash
    }
    catch (ex) {
      return ''
    }
  }, [])

  return { onUnlock: doTx }
}

export default useUnlock
