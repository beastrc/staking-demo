import { useCallback, useEffect, useState } from 'react'


import BigNumber from 'bignumber.js'


import { getCanUnlockLua, getEarned, getLockOf, getMasterChefContract } from '../sushi/utils'
import useSushi from './useSushi'
import useBlock from './useBlock'
import { useWeb3React } from '@web3-react/core'

const useLockBalance = () => {
  const [balance, setBalance] = useState(new BigNumber(0))

  const {account} = useWeb3React()
  const sushi = useSushi()
  const block = useBlock()

  const fetchBalance = useCallback(async () => {
    const balance = await getLockOf(sushi, account)
    setBalance(balance)
  }, [account, sushi])

  useEffect(() => {
    if (account && sushi) {
      fetchBalance()
    }
  }, [account, block, setBalance, sushi])

  return balance
}

export default useLockBalance
