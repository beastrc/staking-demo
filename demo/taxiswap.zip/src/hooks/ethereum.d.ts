interface Window {
  Ethereum?: {
    isMetaMask?: true
    on?: (...args: any[]) => void
    removeListener?: (...args: any[]) => void
    //ethereum : any
  }
  web3?: {}
}
