import React from 'react'
import { Switch, useRouteMatch } from 'react-router-dom'
import { useWallet } from 'use-wallet'
import styled from 'styled-components'

import useModal from '../../hooks/useModal'
import Container from '../../components/Container'
import ConvertMakerCards from '../../components/ConvertMakerCards'
import Spacer from '../../components/Spacer'

import FarmsContainer from './components/FarmsContainer'
import { useWeb3React } from '@web3-react/core'


const Farms: React.FC = () => {
  const { path } = useRouteMatch()
  const { account } = useWeb3React()
  return (
    <>
       {/*<Switch>
      <FarmsContainer />
    </Switch>*/}
      <StyledFarm>
        <StyledCardsWrapper>
          <StyledCardWrapper>
          <Switch>
            <FarmsContainer />
          </Switch>
          </StyledCardWrapper>
          <Spacer/>
        </StyledCardsWrapper>
        <Spacer size="md"/>
      </StyledFarm>


    </>
  )
}
const Box = styled.div`
    &.mt-4 {
        margin-top: 40px;
        @media (max-width: 767px) {
            margin-top: 30px;
        }
    }
`
const SpacerRes = styled.div`
    .sc-iCoHVE {
        @media (max-width: 1024px) {
            display: none;
        }
    }
    .d-lg-none {
        @media (min-width: 1025px) {
            display: none;
        }
    }
`
const StyledHeading = styled.h2`
  color: ${(props) => props.theme.color.white};
  text-transform: uppercase;
  text-align: center;
  margin-bottom: 0;
  margin-top: 0;
`
const StyledFarm = styled.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  @media (max-width: 768px) {
    width: 100%;
  }
`
const StyledParagraph = styled.p`
  color: ${(props) => props.theme.color.grey[100]};
  text-align: center;
  margin-top: 10px;
`
const StyledCardsWrapper = styled.div`
  display: flex;
  width: 900px;
  text-align: center;
  @media (max-width: 768px) {
    width: 100%;
    flex-flow: column nowrap;
    align-items: center;
  }
`

const StyledInfoWrapper = styled.div`
  display: flex;
  width: 900px;
  text-align: center;
  @media (max-width: 768px) {
    width: 100%;
    flex-flow: column nowrap;
    align-items: center;
  }
`

const StyledCardWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  text-align: center;
  @media (max-width: 768px) {
    width: 80%;
  }
`

const StyledInfo = styled.h3`
  color: ${(props) => props.theme.color.grey[400]};
  font-size: 16px;
  font-weight: 400;
  margin: 0;
  padding: 0;
  text-align: center;
`
const StyledNote = styled.div`
margin-left: 15px;
`
const StyledNoteWrapper = styled.h3`
color: ${(props) => props.theme.color.grey[100]};
  font-size: 16px;
  font-weight: 400;
  margin: 0;
  padding: 0;
  text-align: center;
`
export default Farms
