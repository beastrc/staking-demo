export default {
  rpc: 'https://data-seed-prebsc-1-s1.binance.org:8545/',
  chainId: 97,
  api: 'https://wallet.tomochain.com/api/luaswap'
  // api: 'http://localhost:8020'
}