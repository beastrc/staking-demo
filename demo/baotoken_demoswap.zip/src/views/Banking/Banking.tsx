import React, { useState, useEffect} from 'react';
import './App.scss';
import BigNumber from 'bignumber.js'
const Web3 = require("web3")
const  ABI =require('../../web3-handler/abi');

const win = window as any;

function Banking() {

    const web3 = new Web3(Web3.givenProvider);
    const contractAddr = '0xece0ab038a017c314735ed7e768563d37d58ea32';
    //tokenaddress = "0xf63b5971afd486bd86541416bc095bdfb693cd0d"
    const tfiContractAddr = "0xF63B5971Afd486BD86541416bC095bDfb693cD0d"
    const SimpleContract = new web3.eth.Contract(ABI, contractAddr);
    
    const [number, setNumber] = useState(0);
    const [checkMyStake, setCheckMyStake] = useState(0);
    const [totalStaked, setTotalStaked] = useState(0);
    const [calcReward, setCalcReward] = useState(0);

    useEffect(() => {
        async function fetchData() {
            const accounts = await win.ethereum.enable();
            const account = accounts[0];

            SimpleContract.methods.checkMyStake().call({ from: account})
            .then((res: any) => {
                //console.log('[MyState]',res);
                setCheckMyStake(Number(new BigNumber(res).times(new BigNumber(10).pow(-18))));
            })
            .catch((err:any) => {
                console.log(err);
            });

            SimpleContract.methods.totalStaked().call({ from: account})
            .then((res:any) => {
                //console.log('[MyState]',res);
                setTotalStaked(Number(new BigNumber(res).times(new BigNumber(10).pow(-18))));
            })
            .catch((err:any) => {
                console.log(err);
            });

            SimpleContract.methods.calcReward().call({ from: account})
            .then((res:any) => {
                //console.log('[MyState]',res);
                setCalcReward(Number(new BigNumber(res).times(new BigNumber(10).pow(-18))));
            })
            .catch((err:any) => {
                console.log(err);
            });
        }   

        const interval = setInterval(() => {
            fetchData();
        }, 5000);

        return () => clearInterval(interval);
    });

    const handleStake = async (e: any) => {
        e.preventDefault();
        const accounts = await win.ethereum.enable();
        const account = accounts[0];
        var gas;
        try {
            gas = await SimpleContract.methods.stake().estimateGas({
                from: account, 
            });
        } 
        catch(error){
            console.log(error);
            gas = 3000000;           
        }

        const result = await SimpleContract.methods.stake().send({
            from: account,
            gas: gas,
            value: web3.utils.toWei(number.toString(), 'ether')
        })
        .then((res: any)=>{
            console.log(res)

        })
        .catch ((err: any) => {
            console.log(err)
        });
        console.log(result);
    }

    const handleClaim = async (e: any) => {
        e.preventDefault();
        const accounts = await win.ethereum.enable();
        const account = accounts[0];
        var gas;
        try {
            gas = await SimpleContract.methods.stake().estimateGas({
                from: account, 
            });
        } 
        catch(error){
            console.log(error);
            gas = 3000000;           
        }
        console.log(await SimpleContract.methods.claimTFI().send({from: account,gas: gas}))

        // const result = await SimpleContract.methods.claimTFI().send({
        //     from: account,
        //     gas: gas,
        //     })
        
        // console.log(result)

        // })
        // .then((res: any)=>{
        //     console.log(res)

        // })
        // .catch ((err: any) => {
        //     console.log(err)
        // });
        // console.log(result);
    }

    return (

        <div className="App">
            <header className="App-header">
                <form onSubmit={handleStake}>          
                    <label>
                        Stake amount:
                        <input type="text" name="name" value={number} onChange={ e => setNumber(Number(e.target.value)) }  />
                    </label>
                    <input type="submit" value="Stake" />
                </form>
                <br/>
                <div>Your TRX Stake : { checkMyStake }</div>
                <div>total : { totalStaked }</div>
                <div>Your TPI Reward : { calcReward }</div>

                <button onClick={handleClaim}>Claim TFI rewards</button>
            </header>
        </div>

    );
};

export default Banking