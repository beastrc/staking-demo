// export const bao = '0x0e2298e3b3390e3b945a5456fbf59ecc3f55da16'
export const baov2 = '0xF52B61D4D0BA9990e1a44c6Ce26Ea41b16F3eF77'
export const baoAddress = '0xF52B61D4D0BA9990e1a44c6Ce26Ea41b16F3eF77'
export const masterChefAddress = '0x7EDEAb4AcadF2057C3302eF1Ea2bf61e54C43b04'
